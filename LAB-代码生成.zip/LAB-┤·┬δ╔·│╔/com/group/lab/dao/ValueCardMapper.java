package com.group.lab.dao;

import com.group.lab.model.ValueCard;
import com.group.lab.model.ValueCardExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ValueCardMapper {
    int countByExample(ValueCardExample example);

    int deleteByExample(ValueCardExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ValueCard record);

    int insertSelective(ValueCard record);

    List<ValueCard> selectByExample(ValueCardExample example);

    ValueCard selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") ValueCard record, @Param("example") ValueCardExample example);

    int updateByExample(@Param("record") ValueCard record, @Param("example") ValueCardExample example);

    int updateByPrimaryKeySelective(ValueCard record);

    int updateByPrimaryKey(ValueCard record);
}